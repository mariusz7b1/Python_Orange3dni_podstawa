"""Test modułow 1"""
import mpmodul_2 as rd
wiek = rd.read_int("podaj swoj wiek", 18, 99)
print(wiek)
