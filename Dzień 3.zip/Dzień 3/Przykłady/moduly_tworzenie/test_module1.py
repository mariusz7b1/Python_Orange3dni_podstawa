"""Test modułow 1"""
import mpmodul_1 as po


imie_kursanta = po.powitanie()
po.pozdrowienia(imie_kursanta)
